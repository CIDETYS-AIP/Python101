#Extraer texto de archivos pdf e imagenes
#Edgar Gutierrez 
import os
from PIL import Image
from PyPDF2 import PdfReader
from pytesseract import pytesseract

ruta = r'C:/Users/EDGAR-PC/Desktop/proyecto-cursopython/ruta-archivos' #ruta en el disco duro de los archivos

ruta_tesseract = r'C:/Program Files/Tesseract-OCR/tesseract.exe'#libreria tesseract usa un ejecutable para realizar el procesamiento
pytesseract.tesseract_cmd = ruta_tesseract

cambio_ruta = os.chdir(ruta) #cambia el directorio activo del programa

archivo_pdf = []
archivo_img = []

for archivo in os.listdir(cambio_ruta): # itera sobre la carpeta y agrega todos los archivos que terminen en .pdf
    if archivo.endswith('.pdf'):       # a la lista archivo_pdf
        archivo_pdf.append(archivo)
    elif archivo.endswith('.png') or archivo.endswith('.jpg'): # a la lista archivo_
        archivo_img.append(archivo)
    else:
        print('No se encontró archivo de extension requerida')


nombre_pdf = input("Ingrese nombre del archivo para guardar texto: ")
nombre_img = input("Ingrese el nombre del archivo para guardar texto imagenes: ")

for archivo in archivo_pdf:        #iterador sobre la lista   
    with open(archivo,'rb') as objeto_pdf:    #abre cada archivo en modo binario      
        pdfreader = PdfReader(objeto_pdf)       #se crea un objeto pdf con la libreria de PyPDF
        pagina = pdfreader.pages[0]             
        texto_pdf = pagina.extract_text()           
    guardar_pdf = open(rf"C:/Users/EDGAR-PC/Desktop/proyecto-cursopython/resultados/{nombre_pdf}.txt",'a') #guarda el texto en un archivo txt
    print(f'\nEl texto del archivo {archivo} \n\n{texto_pdf}')
    
    guardar_pdf.writelines(f'\nEl texto del archivo {archivo} \n\n{texto_pdf}')
    guardar_pdf.close()

os.system('cls')

for archivo in archivo_img:
    img = Image.open(archivo)                    #abre la imagen  con pillow
    texto_img = pytesseract.image_to_string(img)  #convierte el cntenido de imagen a cadena

    guardar_img = open(rf"C:/Users/EDGAR-PC/Desktop/proyecto-cursopython/resultados/{nombre_img}.txt",'a') #guarda el texto en una archiv
    print(f"\nEl texto del {archivo} es \n\n{texto_img}")
    guardar_img.writelines(texto_img)
    guardar_img.close()